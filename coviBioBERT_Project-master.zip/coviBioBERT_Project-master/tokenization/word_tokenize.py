from transformers import BertTokenizer
from transformers import AutoTokenizer
bert_tokenizer = BertTokenizer.from_pretrained("bert-base-cased")
biobert_tokenizer = AutoTokenizer.from_pretrained("dmis-lab/biobert-v1.1")

s = "Glycophorin D"

print(bert_tokenizer.tokenize(s))

print(biobert_tokenizer.tokenize(s))