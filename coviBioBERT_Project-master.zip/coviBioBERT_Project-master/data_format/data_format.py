from nltk import tokenize
from bs4 import BeautifulSoup
import sys

f = open('input.txt', 'r', encoding="utf-8")
w = open('result.txt','w', encoding="utf-8")
lines = f.read()

soup = BeautifulSoup(lines,features="html.parser")
clean_data = soup.get_text()
try:
    p = tokenize.sent_tokenize(clean_data)
    for line in p:
        line += '\n'
        w.write(line)
    w.write("\n")
except:
    print("Some Error!", sys.exc_info()[0])




    